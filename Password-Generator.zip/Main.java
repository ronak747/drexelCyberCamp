import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.util.*;

class Main 
{
  public static void main(String[] args) 
  {
    String[] LLetters = new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p",
        "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
    String[] CLetters = new String[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P",
        "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
    String[] SCharacter = new String[] { "@", "$", "#", "~", "*", "!", "%" };
    String password = "";
    ArrayList<String> li = new ArrayList<String>();
    li.addAll(Arrays.asList("a", "b", "c", "d", "j", "f", "g", "h", "i", "e"));
    for (int x = 1; x <= 10; x++) 
    {

      int w = (int) (Math.random() * (li.size() - 1));
      String y = li.get(w);
      li.remove(w);
      if (y == "a" || y == "b" || y == "c") 
      {
        int z = (int) (Math.random() * (25));
        password += LLetters[z];
      } 
      else if (y == "d" || y == "e" || y == "f") 
      {
        int z = (int) (Math.random() * (25));
        password += CLetters[z];
      } 
      else if (y == "g" || y == "h" || y == "i") 
      {
        int z = (int) (Math.random() * (9));
        password += z;
      } 
      else 
      {
        int z = (int) (Math.random() * (6));
        password += SCharacter[z];
      }
    }
    System.out.println("Your random password is: " + password);

  }
}